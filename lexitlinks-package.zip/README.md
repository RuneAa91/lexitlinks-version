# Static Quick-links with GitHub approval

This folder is a downloadable static Quick-links package. It has no Flask app and no backend.

## Files

- `index.html` is the app.
- `static/app.js` and `static/style.css` are the frontend.
- `icons/` contains shared images.
- `data/manifest.json` lists the shared link-set JSON files.
- `data/link-sets/*.json` stores one shared link set per JSON file.
- `data/config.js` stores GitHub repo settings.

Personal links are not included in the shared package. Each user can download or import their own `personal.json` from the Personal menu. That file is browser-local and should not be uploaded to GitHub.

## User Behavior

- `Home` returns to the link-set chooser.
- `+` can add a shared link or a shared link set.
- Shared link additions, edits, deletes, and new sets apply locally immediately and create a GitHub issue request.
- If the same URL is already pending for the same link set, the user gets a warning and the link is saved locally without creating another GitHub issue.
- The same URL can still be submitted to a different link set; that creates its own GitHub issue request.
- This is a static app, so it cannot verify that the user actually clicked Submit on GitHub. After submitting the issue, the user must click `Mark GitHub issue created` in the app.
- `Sync > Download pending request log` includes only requests that were marked as created in GitHub.
- `Save locally` in the GitHub request window applies the request locally without marking it as a GitHub issue.
- `Sync > Download all local requests` exports only requests saved with `Save locally`, for bulk admin approval.
- This project is intended for a private GitHub repository. Each user needs a GitHub account with access to that repository before they can submit requests, view issues, or download approved updates from GitHub.
- `Edit` opens the edit form; delete is available only from that form.
- Stars are local favorites. A favorited link shows a yellow star.
- Drag and drop links inside a link set to create a local custom order.
- `View` supports grouping by grouping, grouping by tag, flat A-Z, favorites first, and custom drag order.

## Images

When adding or editing a link, image fields can use:

- An existing image from the image picker.
- A direct image URL.
- A file uploaded from the user's computer.

For Personal links, uploaded images are stored inside the user's `personal.json` as local browser data.

For shared links, uploaded images are included in the GitHub issue request as files the admin should save into `icons/` when approving. The approved shared JSON should reference the final `icons/...` path.

## GitHub Setup

Edit `data/config.js`:

```javascript
window.QUICK_LINKS_CONFIG = {
  githubOwner: "your-github-user-or-org",
  githubRepo: "your-repo-name",
  githubBranch: "main",
  requestIssueOwner: "RuneAa91",
  requestIssueRepo: "lexitlinks-version",
  issueLabels: ["quick-links-request"],
  packageName: "quick-links",
  publicVersionUrl: "https://raw.githubusercontent.com/RuneAa91/lexitlinks-version/main/version.json",
  publicPackageUrl: "https://raw.githubusercontent.com/RuneAa91/lexitlinks-version/main/lexitlinks-package.zip"
};
```

Help shows:

- Create GitHub account
- Sign in to GitHub

Shared link requests open prefilled issues in `requestIssueOwner/requestIssueRepo`, which should be the public request/version repository. Users do not need access to the private source repository.

The static app does not store a GitHub token. Shared changes open prefilled GitHub issues instead:

- New shared link set
- New shared link
- Edit shared link
- Delete shared link

The user sees their change immediately through local browser storage. GitHub only changes after an admin approves the issue and publishes updated `index.html`, `data/link-sets/*.json`, and images.

## Updates

When an admin publishes a new approved package, update `data/version.json` in the private source repo. The GitHub Action copies `version.json` and `lexitlinks-package.zip` to the public version repo. Users can then use:

```text
Sync > Check for approved updates
```

The app shows a download link for the public approved package ZIP.

If update checking says no version file was found, verify that this exact file exists on the configured branch:

```text
publicVersionUrl from data/config.js
```

For private repos, `publicVersionUrl` should point to a public `version.json` file, for example in a separate public `lexitlinks-version` repository. If that URL is a `raw.githubusercontent.com` URL, the app reads it through GitHub's public contents API to avoid stale raw-file caching. The approved download should be a public ZIP such as `lexitlinks-package.zip` in that same public repo.
