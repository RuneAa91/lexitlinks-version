const CONFIG = window.QUICK_LINKS_CONFIG || {};
const STATIC_DATA = window.QUICK_LINKS_DATA || { manifest: { version: 1, sets: [] }, sets: [] };

const STORAGE_KEYS = {
  activeSet: "quicklinks.static.activeSet",
  personal: "quicklinks.static.personal",
  pending: "quicklinks.static.pendingRequests",
  localOnly: "quicklinks.static.localOnlyLinks",
  prefs: "quicklinks.static.prefs",
  favorites: "quicklinks.static.favorites",
  order: "quicklinks.static.order",
  seenVersion: "quicklinks.static.seenVersion"
};

let baseSets = STATIC_DATA.sets.map((entry) => entry.data);
let personalLinks = readJson(STORAGE_KEYS.personal, []);
let pendingRequests = readJson(STORAGE_KEYS.pending, []);
let localOnlyLinks = readJson(STORAGE_KEYS.localOnly, []);
let prefs = readJson(STORAGE_KEYS.prefs, { sort: "title", view: "grouping" });
let favorites = readJson(STORAGE_KEYS.favorites, {});
let customOrder = readJson(STORAGE_KEYS.order, {});
let activeSet = localStorage.getItem(STORAGE_KEYS.activeSet) || "";
let editingLink = null;
let formMode = "new";
let draggedLinkId = "";
let activeGithubRequest = null;

const els = {
  setChooser: document.getElementById("setChooser"),
  linkView: document.getElementById("linkView"),
  activeSetLabel: document.getElementById("activeSetLabel"),
  updateNotice: document.getElementById("updateNotice"),
  search: document.getElementById("search"),
  statusLine: document.getElementById("statusLine"),
  bulkActions: document.getElementById("bulkActions"),
  list: document.getElementById("list"),
  homeBtn: document.getElementById("homeBtn"),
  addBtn: document.getElementById("addBtn"),
  navMenuBtn: document.getElementById("navMenuBtn"),
  personalMenuBtn: document.getElementById("personalMenuBtn"),
  viewMenuBtn: document.getElementById("viewMenuBtn"),
  syncMenuBtn: document.getElementById("syncMenuBtn"),
  helpMenuBtn: document.getElementById("helpMenuBtn"),
  linkDialog: document.getElementById("linkDialog"),
  linkDialogTitle: document.getElementById("linkDialogTitle"),
  linkForm: document.getElementById("linkForm"),
  deleteFromEditBtn: document.getElementById("deleteFromEditBtn"),
  duplicateWarning: document.getElementById("duplicateWarning"),
  image1Preview: document.getElementById("image1Preview"),
  image2Preview: document.getElementById("image2Preview"),
  image1Picker: document.getElementById("image1Picker"),
  image2Picker: document.getElementById("image2Picker"),
  setDialog: document.getElementById("setDialog"),
  setForm: document.getElementById("setForm"),
  setNameInput: document.getElementById("setNameInput"),
  requestDialog: document.getElementById("requestDialog"),
  requestBody: document.getElementById("requestBody"),
  githubIssueLink: document.getElementById("githubIssueLink"),
  markGithubCreatedBtn: document.getElementById("markGithubCreatedBtn"),
  saveRequestLocallyBtn: document.getElementById("saveRequestLocallyBtn"),
  aboutDialog: document.getElementById("aboutDialog")
};

function readJson(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
  } catch {
    return fallback;
  }
}

function writeJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function normalizeUrl(value) {
  const url = String(value || "").trim();
  if (!url) return "";
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(url)) return url;
  if (url.startsWith("//")) return `https:${url}`;
  if (url.toLowerCase().startsWith("www.")) return `https://${url}`;
  return `https://www.${url}`;
}

function normalizeLink(payload, personal = false) {
  return {
    id: payload.id || crypto.randomUUID(),
    title: String(payload.title || "").trim(),
    description: String(payload.description || "").trim(),
    url: normalizeUrl(payload.url),
    tags: Array.isArray(payload.tags)
      ? payload.tags
      : String(payload.tags || "").split(",").map((tag) => tag.trim()).filter(Boolean),
    grouping: String(payload.grouping || "Other").trim() || "Other",
    image1: String(payload.image1 || "").trim(),
    image2: String(payload.image2 || "").trim(),
    linkSet: personal ? "Personal" : String(payload.linkSet || "Application").trim()
  };
}

function linkId(link) {
  return `${link.personal ? "personal" : "shared"}:${link.id}`;
}

function isFavorite(link) {
  return Boolean(favorites[linkId(link)]);
}

function setOrderForActiveSet(orderedIds) {
  if (!activeSet) return;
  customOrder[activeSet] = orderedIds;
  writeJson(STORAGE_KEYS.order, customOrder);
}

function orderedIndex(link) {
  const order = customOrder[activeSet] || [];
  const index = order.indexOf(linkId(link));
  return index === -1 ? 999999 : index;
}

function baseLinks() {
  return baseSets.flatMap((set) => set.links || []);
}

function sharedSetNames() {
  const names = new Set(baseSets.map((set) => set.name));
  pendingRequests
    .filter((request) => request.type === "new_set")
    .forEach((request) => names.add(request.name));
  pendingRequests
    .filter((request) => request.item && request.item.linkSet)
    .forEach((request) => names.add(request.item.linkSet));
  return [...names].sort();
}

function currentSharedLinks() {
  let links = [
    ...baseLinks().map((link) => ({ ...link, source: "base" })),
    ...localOnlyLinks.map((link) => ({ ...link, source: "local-only" }))
  ];
  for (const request of pendingRequests) {
    if (request.type === "new_link") {
      links.push({ ...request.item, source: "local-pending" });
    } else if (request.type === "edit_link") {
      links = links.map((link) => link.id === request.linkId ? { ...request.item, source: "local-pending" } : link);
    } else if (request.type === "delete_link") {
      links = links.filter((link) => link.id !== request.linkId);
    } else if (request.type === "new_set") {
      continue;
    }
  }
  return links;
}

function allLinks() {
  return [
    ...currentSharedLinks().map((link) => ({ ...link, personal: false })),
    ...personalLinks.map((link) => ({ ...link, personal: true, linkSet: "Personal" }))
  ];
}

function setOptions() {
  return [...sharedSetNames(), "Personal"];
}

function render() {
  renderDatalists();
  renderSetChooser();
  renderUpdateNotice();

  if (!activeSet || !setOptions().includes(activeSet)) {
    els.linkView.classList.add("hidden");
    els.setChooser.classList.remove("hidden");
    els.activeSetLabel.textContent = "Select a link set";
    return;
  }

  els.linkView.classList.remove("hidden");
  els.setChooser.classList.add("hidden");
  els.activeSetLabel.textContent = activeSet === "Personal"
    ? "Personal links are stored only in this browser and are not sent to GitHub"
    : `${activeSet} link set`;

  const search = els.search.value.trim().toLowerCase();
  const links = allLinks().filter((link) => {
    if (link.linkSet !== activeSet) return false;
    return !search
      || link.title.toLowerCase().includes(search)
      || link.description.toLowerCase().includes(search)
      || link.grouping.toLowerCase().includes(search)
      || link.tags.some((tag) => tag.toLowerCase().includes(search));
  });

  els.statusLine.textContent = `${links.length} visible links${pendingRequests.length ? ` | ${pendingRequests.length} local requests waiting for GitHub approval` : ""}`;
  renderBulkActions();
  renderLinkList(links);
}

function renderSetChooser() {
  els.setChooser.innerHTML = "";
  for (const setName of setOptions()) {
    const count = allLinks().filter((link) => link.linkSet === setName).length;
    const card = document.createElement("button");
    card.className = "set-card";
    card.innerHTML = `<strong>${escapeHtml(setName)}</strong><span>${count} links${setName === "Personal" ? " local only" : ""}</span>`;
    card.onclick = () => {
      activeSet = setName;
      localStorage.setItem(STORAGE_KEYS.activeSet, activeSet);
      render();
    };
    els.setChooser.appendChild(card);
  }
}

function renderBulkActions() {
  els.bulkActions.innerHTML = "";
  if (!activeSet) return;
  const download = document.createElement("button");
  download.textContent = activeSet === "Personal" ? "Download personal.json" : `Download ${activeSet}.json`;
  download.onclick = () => activeSet === "Personal" ? downloadPersonalJson() : downloadSetJson(activeSet);
  els.bulkActions.appendChild(download);
}

function renderLinkList(links) {
  els.list.innerHTML = "";
  if (!links.length) {
    els.list.innerHTML = `<div class="pending-item">No links in this set.</div>`;
    return;
  }

  if (prefs.view === "flat") {
    sortLinks(links).forEach(renderLinkCard);
    return;
  }

  const groups = {};
  for (const link of links) {
    const groupName = prefs.view === "tags" ? (link.tags[0] || "No tag") : (link.grouping || "Other");
    groups[groupName] = groups[groupName] || [];
    groups[groupName].push(link);
  }

  Object.keys(groups).sort().forEach((groupName) => {
    const header = document.createElement("div");
    header.className = "group-header";
    header.textContent = groupName;
    els.list.appendChild(header);
    sortLinks(groups[groupName]).forEach(renderLinkCard);
  });
}

function sortLinks(links) {
  return [...links].sort((a, b) => {
    if (prefs.sort === "favorites" && isFavorite(a) !== isFavorite(b)) return isFavorite(a) ? -1 : 1;
    if (prefs.sort === "custom" && orderedIndex(a) !== orderedIndex(b)) return orderedIndex(a) - orderedIndex(b);
    return a.title.localeCompare(b.title);
  });
}

function renderLinkCard(link) {
  const row = document.createElement("div");
  row.className = `link-card${isFavorite(link) ? " is-favorite" : ""}`;
  row.draggable = true;
  row.dataset.linkId = linkId(link);
  const pending = link.source === "local-pending" ? `<span class="status-pill pending">pending</span>` : "";
  const localOnly = link.source === "local-only" ? `<span class="status-pill pending">local only</span>` : "";
  row.innerHTML = `
    <a class="left" href="${escapeAttr(link.url)}" target="_blank" rel="noreferrer">
      <span class="icon-pair">${imageHtml(link.image1)}${imageHtml(link.image2)}</span>
      <span class="text">
        <span class="title">${escapeHtml(link.title)} ${pending}${localOnly}</span>
        <span class="desc">${escapeHtml(link.description || link.url)}</span>
        <span class="tags">${escapeHtml((link.tags || []).join(", "))}</span>
      </span>
    </a>
    <span class="actions">
      <button class="star-button${isFavorite(link) ? " is-favorite" : ""}" title="Favorite" aria-label="Favorite" data-favorite>★</button>
      <button data-edit>Edit</button>
    </span>
  `;
  row.querySelector("[data-favorite]").onclick = (event) => {
    event.preventDefault();
    event.stopPropagation();
    toggleFavorite(link);
  };
  row.querySelector("[data-edit]").onclick = () => openEditDialog(link);
  row.addEventListener("dragstart", (event) => {
    draggedLinkId = row.dataset.linkId;
    row.classList.add("dragging");
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", draggedLinkId);
  });
  row.addEventListener("dragend", () => {
    draggedLinkId = "";
    row.classList.remove("dragging");
    document.querySelectorAll(".drag-over").forEach((node) => node.classList.remove("drag-over"));
  });
  row.addEventListener("dragover", (event) => {
    event.preventDefault();
    if (draggedLinkId && draggedLinkId !== row.dataset.linkId) row.classList.add("drag-over");
  });
  row.addEventListener("dragleave", () => row.classList.remove("drag-over"));
  row.addEventListener("drop", (event) => {
    event.preventDefault();
    row.classList.remove("drag-over");
    reorderVisibleLinks(draggedLinkId, row.dataset.linkId);
  });
  els.list.appendChild(row);
}

function toggleFavorite(link) {
  const key = linkId(link);
  if (favorites[key]) {
    delete favorites[key];
  } else {
    favorites[key] = true;
  }
  writeJson(STORAGE_KEYS.favorites, favorites);
  render();
}

function reorderVisibleLinks(fromId, toId) {
  if (!fromId || !toId || fromId === toId) return;
  const visibleIds = [...els.list.querySelectorAll(".link-card")].map((node) => node.dataset.linkId);
  const fromIndex = visibleIds.indexOf(fromId);
  const toIndex = visibleIds.indexOf(toId);
  if (fromIndex === -1 || toIndex === -1) return;
  visibleIds.splice(toIndex, 0, visibleIds.splice(fromIndex, 1)[0]);
  const previous = customOrder[activeSet] || [];
  const hiddenIds = previous.filter((id) => !visibleIds.includes(id));
  const allActiveIds = allLinks().filter((link) => link.linkSet === activeSet).map(linkId);
  const missingIds = allActiveIds.filter((id) => !visibleIds.includes(id) && !hiddenIds.includes(id));
  setOrderForActiveSet([...visibleIds, ...hiddenIds, ...missingIds]);
  prefs.sort = "custom";
  writeJson(STORAGE_KEYS.prefs, prefs);
  render();
}

function imageHtml(src) {
  return src ? `<img src="${escapeAttr(src)}" alt="">` : `<span class="icon-empty"></span>`;
}

function openAddDialog() {
  formMode = "new";
  editingLink = null;
  els.linkDialogTitle.textContent = activeSet === "Personal" ? "Add personal link" : "Add shared link";
  els.linkForm.reset();
  els.deleteFromEditBtn.classList.add("hidden");
  els.duplicateWarning.classList.add("hidden");
  renderSetSelect(activeSet || "Application");
  renderImagePickers();
  updateImagePreviews();
  els.linkDialog.showModal();
}

function openEditDialog(link) {
  formMode = "edit";
  editingLink = link;
  els.linkDialogTitle.textContent = link.personal ? "Edit personal link" : "Edit shared link";
  els.linkForm.elements.title.value = link.title;
  els.linkForm.elements.description.value = link.description || "";
  els.linkForm.elements.url.value = link.url;
  els.linkForm.elements.tags.value = (link.tags || []).join(", ");
  els.linkForm.elements.grouping.value = link.grouping || "";
  els.linkForm.elements.image1.value = link.image1 || "";
  els.linkForm.elements.image2.value = link.image2 || "";
  els.linkForm.elements.image1File.value = "";
  els.linkForm.elements.image2File.value = "";
  renderSetSelect(link.linkSet);
  els.deleteFromEditBtn.classList.remove("hidden");
  renderImagePickers();
  updateImagePreviews();
  els.linkDialog.showModal();
}

function renderSetSelect(selected) {
  const select = els.linkForm.elements.linkSet;
  select.innerHTML = "";
  for (const setName of setOptions()) {
    const option = document.createElement("option");
    option.value = setName;
    option.textContent = setName;
    option.selected = setName === selected;
    select.appendChild(option);
  }
}

async function handleLinkForm(event) {
  event.preventDefault();
  const form = new FormData(els.linkForm);
  const personal = form.get("linkSet") === "Personal";
  const image1 = await resolveImageValue("image1", personal);
  const image2 = await resolveImageValue("image2", personal);
  const item = normalizeLink({
    id: editingLink ? editingLink.id : undefined,
    title: form.get("title"),
    description: form.get("description"),
    url: form.get("url"),
    tags: form.get("tags"),
    grouping: form.get("grouping"),
    image1: image1.src,
    image2: image2.src,
    linkSet: form.get("linkSet")
  }, personal);

  if (!item.title || !item.url) return;

  if (personal) {
    if (formMode === "edit") {
      personalLinks = personalLinks.map((link) => link.id === editingLink.id ? item : link);
    } else {
      personalLinks.push(item);
    }
    writeJson(STORAGE_KEYS.personal, personalLinks);
    activeSet = "Personal";
    localStorage.setItem(STORAGE_KEYS.activeSet, activeSet);
    els.linkDialog.close();
    render();
    return;
  }

  if (editingLink && editingLink.source === "local-only") {
    localOnlyLinks = localOnlyLinks.map((link) => link.id === editingLink.id ? item : link);
    writeJson(STORAGE_KEYS.localOnly, localOnlyLinks);
    activeSet = item.linkSet;
    localStorage.setItem(STORAGE_KEYS.activeSet, activeSet);
    els.linkDialog.close();
    render();
    return;
  }

  const type = formMode === "edit" ? "edit_link" : "new_link";
  if (type === "new_link") {
    const duplicatePending = await hasPendingDuplicateLink(item);
    if (duplicatePending) {
      alert("There is already a pending request for this exact link in this link set. It will be saved locally only, without creating a duplicate GitHub request.");
      localOnlyLinks.push(item);
      writeJson(STORAGE_KEYS.localOnly, localOnlyLinks);
      activeSet = item.linkSet;
      localStorage.setItem(STORAGE_KEYS.activeSet, activeSet);
      els.linkDialog.close();
      render();
      return;
    }
  }
  addPendingRequest({
    type,
    linkId: editingLink ? editingLink.id : item.id,
    item,
    images: [image1, image2].filter((image) => image.upload),
    title: `${type === "edit_link" ? "Edit link" : "New link"}: ${item.title}`
  });
  activeSet = item.linkSet;
  localStorage.setItem(STORAGE_KEYS.activeSet, activeSet);
  els.linkDialog.close();
  render();
}

function deleteLink(link) {
  if (!confirm(`Delete ${link.title}?`)) return;
  if (link.personal) {
    personalLinks = personalLinks.filter((item) => item.id !== link.id);
    writeJson(STORAGE_KEYS.personal, personalLinks);
  } else if (link.source === "local-only") {
    localOnlyLinks = localOnlyLinks.filter((item) => item.id !== link.id);
    writeJson(STORAGE_KEYS.localOnly, localOnlyLinks);
  } else {
    addPendingRequest({
      type: "delete_link",
      linkId: link.id,
      item: link,
      title: `Delete link: ${link.title}`
    });
  }
  render();
}

async function deleteFromEdit() {
  if (!editingLink) return;
  els.linkDialog.close();
  deleteLink(editingLink);
}

function renderImagePickers() {
  const images = [...new Set(currentSharedLinks().flatMap((link) => [link.image1, link.image2]).filter(Boolean))].sort();
  renderImagePicker(els.image1Picker, "image1", images);
  renderImagePicker(els.image2Picker, "image2", images);
}

function renderImagePicker(container, fieldName, images) {
  container.innerHTML = images.map((src) => `
    <button class="image-choice" type="button" title="${escapeAttr(src)}" data-image-src="${escapeAttr(src)}">
      <img src="${escapeAttr(src)}" alt="">
    </button>
  `).join("");
  container.querySelectorAll("[data-image-src]").forEach((button) => {
    button.onclick = () => {
      els.linkForm.elements[fieldName].value = button.dataset.imageSrc;
      els.linkForm.elements[`${fieldName}File`].value = "";
      updateImagePreviews();
    };
  });
}

function updateImagePreviews() {
  updateImagePreview("image1", els.image1Preview);
  updateImagePreview("image2", els.image2Preview);
}

function updateImagePreview(fieldName, img) {
  const file = els.linkForm.elements[`${fieldName}File`].files[0];
  if (file) {
    img.src = URL.createObjectURL(file);
    return;
  }
  const src = els.linkForm.elements[fieldName].value.trim();
  img.src = src || "";
}

async function resolveImageValue(fieldName, personal) {
  const fileInput = els.linkForm.elements[`${fieldName}File`];
  const textInput = els.linkForm.elements[fieldName];
  const file = fileInput.files && fileInput.files[0];
  if (!file) return { src: textInput.value.trim(), upload: null };

  const dataUrl = await readFileAsDataUrl(file);
  if (personal) return { src: dataUrl, upload: null };

  const target = `icons/${fileSlug(file.name)}`;
  textInput.value = target;
  return {
    src: target,
    upload: {
      field: fieldName,
      target,
      name: file.name,
      type: file.type,
      size: file.size,
      dataUrl
    }
  };
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function openSetDialog() {
  els.setNameInput.value = "";
  els.setDialog.showModal();
}

function handleSetForm(event) {
  event.preventDefault();
  const name = els.setNameInput.value.trim();
  if (!name) return;
  addPendingRequest({ type: "new_set", name, title: `New link set: ${name}` });
  activeSet = name;
  localStorage.setItem(STORAGE_KEYS.activeSet, activeSet);
  els.setDialog.close();
  render();
}

function addPendingRequest(request) {
  const fullRequest = {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    ...request
  };
  openGithubRequest(fullRequest);
}

async function hasPendingDuplicateLink(item) {
  const targetUrl = normalizeUrl(item.url).toLowerCase();
  const targetSet = String(item.linkSet || "").toLowerCase();
  const localDuplicate = pendingRequests.some((request) => {
    if (request.type !== "new_link" || !request.item) return false;
    return normalizeUrl(request.item.url).toLowerCase() === targetUrl
      && String(request.item.linkSet || "").toLowerCase() === targetSet;
  });
  if (localDuplicate) return true;

  const githubRequests = await fetchOpenGithubRequests();
  return githubRequests.some((request) => {
    if (request.type !== "new_link" || !request.item) return false;
    return normalizeUrl(request.item.url).toLowerCase() === targetUrl
      && String(request.item.linkSet || "").toLowerCase() === targetSet;
  });
}

async function fetchOpenGithubRequests() {
  if (!CONFIG.githubOwner || !CONFIG.githubRepo) return [];
  const labels = (CONFIG.issueLabels || []).join(",");
  const params = new URLSearchParams({ state: "open", per_page: "100" });
  if (labels) params.set("labels", labels);
  try {
    const response = await fetch(`https://api.github.com/repos/${encodeURIComponent(CONFIG.githubOwner)}/${encodeURIComponent(CONFIG.githubRepo)}/issues?${params}`, {
      headers: { "Accept": "application/vnd.github+json" }
    });
    if (!response.ok) return [];
    const issues = await response.json();
    return issues
      .map((issue) => parseGithubIssueRequest(issue.body || ""))
      .filter(Boolean);
  } catch {
    return [];
  }
}

function parseGithubIssueRequest(body) {
  const text = String(body || "").trim();
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    const parsed = JSON.parse(text.slice(start, end + 1));
    return parsed && parsed.app === "quick-links" ? parsed : null;
  } catch {
    return null;
  }
}

function openGithubRequest(request) {
  activeGithubRequest = request;
  const githubImages = (request.images || []).map((image) => ({
    field: image.field,
    target: image.target,
    name: image.name,
    type: image.type,
    size: image.size,
    note: "Attach this image file to the GitHub issue. Admin should save it at target in the icons folder when approving."
  }));
  const body = JSON.stringify({
    app: "quick-links",
    requestId: request.id,
    createdAt: request.createdAt,
    type: request.type,
    linkId: request.linkId || "",
    name: request.name || "",
    item: request.item || null,
    imagesToSaveInGithub: githubImages
  }, null, 2);
  els.requestBody.value = body;
  const url = githubIssueUrl(request.title, body);
  els.githubIssueLink.href = url || "#";
  els.githubIssueLink.textContent = url ? "Open GitHub issue" : "GitHub repo is not configured";
  els.githubIssueLink.toggleAttribute("aria-disabled", !url);
  els.markGithubCreatedBtn.disabled = !url;
  els.requestDialog.showModal();
}

function markGithubIssueCreated() {
  if (!activeGithubRequest) return;
  const exists = pendingRequests.some((request) => request.id === activeGithubRequest.id);
  if (!exists) {
    pendingRequests.push({ ...activeGithubRequest, githubIssueMarkedCreatedAt: new Date().toISOString() });
    writeJson(STORAGE_KEYS.pending, pendingRequests);
  }
  els.requestDialog.close();
  activeGithubRequest = null;
  render();
}

function saveRequestLocally() {
  if (!activeGithubRequest) return;
  const exists = pendingRequests.some((request) => request.id === activeGithubRequest.id);
  if (!exists) {
    pendingRequests.push({ ...activeGithubRequest, localSavedAt: new Date().toISOString() });
    writeJson(STORAGE_KEYS.pending, pendingRequests);
  }
  els.requestDialog.close();
  activeGithubRequest = null;
  render();
}

function githubIssueUrl(title, body) {
  const owner = CONFIG.requestIssueOwner || CONFIG.githubOwner;
  const repo = CONFIG.requestIssueRepo || CONFIG.githubRepo;
  if (!owner || !repo) return "";
  const labels = (CONFIG.issueLabels || []).join(",");
  const params = new URLSearchParams({ title, body });
  if (labels) params.set("labels", labels);
  return `https://github.com/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/issues/new?${params}`;
}

function renderDatalists() {
  const shared = currentSharedLinks();
  fillDatalist("tagOptions", [...new Set(shared.flatMap((link) => link.tags || []))]);
  fillDatalist("groupOptions", [...new Set(shared.map((link) => link.grouping).filter(Boolean))]);
  fillDatalist("imageOptions", [...new Set(shared.flatMap((link) => [link.image1, link.image2]).filter(Boolean))]);
}

function fillDatalist(id, values) {
  document.getElementById(id).innerHTML = values.sort().map((value) => `<option value="${escapeAttr(value)}"></option>`).join("");
}

function showDropdown(button, items) {
  closeDropdown();
  const dropdown = document.createElement("div");
  dropdown.className = "dropdown";
  for (const item of items) {
    const child = document.createElement("button");
    child.textContent = item.label;
    child.onclick = () => {
      closeDropdown();
      item.action();
    };
    dropdown.appendChild(child);
  }
  document.body.appendChild(dropdown);
  const rect = button.getBoundingClientRect();
  dropdown.style.top = `${rect.bottom + 6}px`;
  dropdown.style.right = `${Math.max(8, window.innerWidth - rect.right)}px`;
}

function closeDropdown() {
  document.querySelectorAll(".dropdown").forEach((node) => node.remove());
}

function renderUpdateNotice() {
  const latest = localStorage.getItem("quicklinks.static.latestUpdate");
  if (!latest) {
    els.updateNotice.classList.add("hidden");
    return;
  }
  els.updateNotice.classList.remove("hidden");
  els.updateNotice.innerHTML = latest;
}

async function checkForUpdates() {
  if (!CONFIG.githubOwner || !CONFIG.githubRepo) {
    alert("Set githubOwner and githubRepo in data/config.js first.");
    return;
  }
  const branch = CONFIG.githubBranch || "main";
  const rawBase = `https://raw.githubusercontent.com/${CONFIG.githubOwner}/${CONFIG.githubRepo}/${branch}`;
  const fallbackVersionUrl = `${rawBase}/data/version.json`;
  const versionUrl = CONFIG.publicVersionUrl || fallbackVersionUrl;
  try {
    const versionSource = versionFetchSource(versionUrl);
    const fetchUrl = `${versionSource.url}${versionSource.url.includes("?") ? "&" : "?"}cachebust=${Date.now()}`;
    const response = await fetch(fetchUrl, {
      cache: "no-store",
      headers: versionSource.api ? { "Accept": "application/vnd.github+json" } : {}
    });
    if (response.status === 404) {
      throw new Error(`No version file found at ${versionUrl}. If you use a private repo, set publicVersionUrl in data/config.js to a publicly readable version.json file.`);
    }
    if (!response.ok) {
      throw new Error(`GitHub returned ${response.status} for ${versionUrl}. The version file must be publicly readable by this static HTML app.`);
    }
    let remote;
    try {
      if (versionSource.api) {
        const apiPayload = await response.json();
        remote = JSON.parse(atob(String(apiPayload.content || "").replace(/\s/g, "")));
      } else {
        remote = await response.json();
      }
    } catch (error) {
      throw new Error(`The version file at ${versionUrl} is not valid JSON. Check for missing commas, quotes, or braces.`);
    }
    const currentVersion = STATIC_DATA.manifest.version || 1;
    if (Number(remote.version || 0) <= Number(currentVersion)) {
      alert("No newer approved package was found.");
      return;
    }
    const publicPackageUrl = remote.packageUrl || remote.downloadUrl || CONFIG.publicPackageUrl || "";
    const packageLink = publicPackageUrl ? `
        <a class="button-link primary" href="${escapeAttr(publicPackageUrl)}" target="_blank" rel="noreferrer">Download approved package</a>
      ` : "";
    const releaseLink = remote.releaseUrl ? `
        <a class="button-link" href="${escapeAttr(remote.releaseUrl)}" target="_blank" rel="noreferrer">Release notes</a>
      ` : "";
    const html = `
      <strong>Approved update available:</strong> version ${escapeHtml(remote.version)}
      <div class="desc">${escapeHtml(remote.message || remote.updatedAt || "")}</div>
      <div class="pending-actions">
        ${packageLink}
        ${releaseLink}
      </div>
    `;
    localStorage.setItem("quicklinks.static.latestUpdate", html);
    renderUpdateNotice();
  } catch (error) {
    alert(`Could not check updates: ${error.message}`);
  }
}

function versionFetchSource(versionUrl) {
  const apiUrl = CONFIG.publicVersionApiUrl || githubContentsApiUrl(versionUrl);
  return apiUrl ? { url: apiUrl, api: true } : { url: versionUrl, api: false };
}

function githubContentsApiUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (url.hostname !== "raw.githubusercontent.com") return "";
    const parts = url.pathname.split("/").filter(Boolean);
    if (parts.length < 4) return "";
    const [owner, repo, branch, ...pathParts] = parts;
    return `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${pathParts.map(encodeURIComponent).join("/")}?ref=${encodeURIComponent(branch)}`;
  } catch {
    return "";
  }
}

function downloadSetJson(setName) {
  const payload = {
    version: STATIC_DATA.manifest.version || 1,
    updatedAt: new Date().toISOString(),
    name: setName,
    links: sortLinks(currentSharedLinks().filter((link) => link.linkSet === setName)).map(stripRuntimeFields)
  };
  downloadJson(`${fileSlug(setName)}.json`, payload);
}

function downloadAllSharedJson() {
  sharedSetNames().forEach(downloadSetJson);
}

function downloadPersonalJson() {
  downloadJson("personal.json", {
    version: 1,
    updatedAt: new Date().toISOString(),
    name: "Personal",
    links: personalLinks
  });
}

function importPersonalJson() {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".json,application/json";
  input.onchange = async () => {
    const file = input.files && input.files[0];
    if (!file) return;
    const data = JSON.parse(await file.text());
    personalLinks = Array.isArray(data) ? data : data.links || [];
    writeJson(STORAGE_KEYS.personal, personalLinks);
    activeSet = "Personal";
    localStorage.setItem(STORAGE_KEYS.activeSet, activeSet);
    render();
  };
  input.click();
}

function downloadPendingRequests() {
  const markedRequests = pendingRequests.filter((request) => request.githubIssueMarkedCreatedAt);
  if (!markedRequests.length) {
    alert("There are no requests marked as created in GitHub yet. The log only includes requests after you open GitHub, submit the issue there, and click 'Mark GitHub issue created' in this app.");
    return;
  }
  downloadJson("quick-links-pending-github-requests.json", markedRequests);
}

function downloadAllLocalRequests() {
  const requests = pendingRequests.filter((request) => request.localSavedAt);
  if (!requests.length) {
    alert("There are no locally saved shared requests to export. Use 'Save locally' in the GitHub request window first.");
    return;
  }
  downloadJson("quick-links-all-local-requests.json", {
    exportedAt: new Date().toISOString(),
    note: "This file contains requests saved locally from the GitHub request window. It can be sent to an admin for bulk approval.",
    requests
  });
}

function clearPendingRequests() {
  if (!confirm("Clear local pending GitHub requests? This does not change GitHub.")) return;
  pendingRequests = [];
  writeJson(STORAGE_KEYS.pending, pendingRequests);
  render();
}

function stripRuntimeFields(link) {
  const { source, personal, ...clean } = link;
  return clean;
}

function downloadJson(filename, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function fileSlug(name) {
  const value = String(name || "links");
  const dot = value.lastIndexOf(".");
  const stem = dot > 0 ? value.slice(0, dot) : value;
  const ext = dot > 0 ? value.slice(dot).replace(/[^A-Za-z0-9.]/g, "") : "";
  return `${stem.replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-|-$/g, "") || "links"}${ext}`;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[char]));
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, "&#096;");
}

els.homeBtn.onclick = () => {
  activeSet = "";
  localStorage.removeItem(STORAGE_KEYS.activeSet);
  render();
};
els.addBtn.onclick = () => showDropdown(els.addBtn, [
  { label: activeSet === "Personal" ? "Add personal link" : "Add link", action: openAddDialog },
  { label: "Add shared link set", action: openSetDialog }
]);
els.navMenuBtn.onclick = () => showDropdown(els.navMenuBtn, [
  { label: "All link sets", action: () => { activeSet = ""; localStorage.removeItem(STORAGE_KEYS.activeSet); render(); } },
  { label: "Add shared link set", action: openSetDialog },
  { label: "Download all shared JSON files", action: downloadAllSharedJson }
]);
els.personalMenuBtn.onclick = () => showDropdown(els.personalMenuBtn, [
  { label: "Open Personal", action: () => { activeSet = "Personal"; localStorage.setItem(STORAGE_KEYS.activeSet, activeSet); render(); } },
  { label: "Download personal.json", action: downloadPersonalJson },
  { label: "Import personal.json", action: importPersonalJson }
]);
els.viewMenuBtn.onclick = () => showDropdown(els.viewMenuBtn, [
  { label: "Group by grouping A-Z", action: () => { prefs.view = "grouping"; prefs.sort = "title"; writeJson(STORAGE_KEYS.prefs, prefs); render(); } },
  { label: "Group by tag A-Z", action: () => { prefs.view = "tags"; prefs.sort = "title"; writeJson(STORAGE_KEYS.prefs, prefs); render(); } },
  { label: "Flat list A-Z", action: () => { prefs.view = "flat"; prefs.sort = "title"; writeJson(STORAGE_KEYS.prefs, prefs); render(); } },
  { label: "Favorites first", action: () => { prefs.sort = "favorites"; writeJson(STORAGE_KEYS.prefs, prefs); render(); } },
  { label: "Custom drag order", action: () => { prefs.view = "flat"; prefs.sort = "custom"; writeJson(STORAGE_KEYS.prefs, prefs); render(); } }
]);
els.syncMenuBtn.onclick = () => showDropdown(els.syncMenuBtn, [
  { label: "Check for approved updates", action: checkForUpdates },
  { label: "Download pending request log", action: downloadPendingRequests },
  { label: "Download all local requests", action: downloadAllLocalRequests },
  { label: "Clear local pending requests", action: clearPendingRequests }
]);
els.helpMenuBtn.onclick = () => els.aboutDialog.showModal();
els.linkForm.onsubmit = handleLinkForm;
els.deleteFromEditBtn.onclick = deleteFromEdit;
els.markGithubCreatedBtn.onclick = markGithubIssueCreated;
els.saveRequestLocallyBtn.onclick = saveRequestLocally;
els.setForm.onsubmit = handleSetForm;
els.search.oninput = render;
["image1", "image2"].forEach((fieldName) => {
  els.linkForm.elements[fieldName].addEventListener("input", updateImagePreviews);
  els.linkForm.elements[`${fieldName}File`].addEventListener("change", updateImagePreviews);
});

document.querySelectorAll("[data-close-dialog]").forEach((button) => button.onclick = () => els.linkDialog.close());
document.querySelectorAll("[data-close-set]").forEach((button) => button.onclick = () => els.setDialog.close());
document.querySelectorAll("[data-close-request]").forEach((button) => button.onclick = () => els.requestDialog.close());
document.querySelectorAll("[data-close-about]").forEach((button) => button.onclick = () => els.aboutDialog.close());
document.addEventListener("click", (event) => {
  if (!event.target.closest(".dropdown") && !event.target.closest(".top-actions button")) closeDropdown();
});

render();
