window.QUICK_LINKS_DATA = {
  "manifest": {
    "version": 1,
    "updatedAt": "2026-05-15",
    "sets": [
      {
        "name": "Application",
        "file": "data/link-sets/Application.json",
        "count": 35
      },
      {
        "name": "System",
        "file": "data/link-sets/System.json",
        "count": 1
      }
    ]
  },
  "sets": [
    {
      "name": "Application",
      "file": "data/link-sets/Application.json",
      "count": 35,
      "data": {
        "version": 1,
        "updatedAt": "2026-05-15",
        "name": "Application",
        "links": [
          {
            "id": "33",
            "title": "Bama | BamaPortal",
            "description": "Bamaportal - Planogram",
            "url": "https://bamaportal.lexitcloud.com/login",
            "tags": [
              "Planogram"
            ],
            "grouping": "Bama",
            "image1": "icons/bama.jpg",
            "image2": "icons/lexservice.png",
            "linkSet": "Application"
          },
          {
            "id": "34",
            "title": "Bama | FactoryTalk",
            "description": "Bama FactoryTalk",
            "url": "https://bamasalatbar2.lexitcloud.com/ftcw2/login",
            "tags": [],
            "grouping": "Bama",
            "image1": "icons/bama.jpg",
            "image2": "icons/ft.png",
            "linkSet": "Application"
          },
          {
            "id": "25",
            "title": "LexService",
            "description": "LexService",
            "url": "https://lexservice.lexitgroup.com/Norge/",
            "tags": [
              "Lexit"
            ],
            "grouping": "Lexit",
            "image1": "icons/lexit.jpg",
            "image2": "icons/lexservice.png",
            "linkSet": "Application"
          },
          {
            "id": "1",
            "title": "Lexit | Dynamics",
            "description": "Lexit Dynamics mainpage",
            "url": "https://lexit.crm19.dynamics.com",
            "tags": [],
            "grouping": "Lexit",
            "image1": "icons/lexit.jpg",
            "image2": "icons/dynamics.webp",
            "linkSet": "Application"
          },
          {
            "id": "8",
            "title": "Lexit | LexNoMDM",
            "description": "Soti felles kundeserver",
            "url": "https://lexnomdm.lexitcloud.com/MobiControl/webconsole/",
            "tags": [
              "Bama",
              "Menzies"
            ],
            "grouping": "Lexit",
            "image1": "icons/lexit.jpg",
            "image2": "icons/soti.png",
            "linkSet": "Application"
          },
          {
            "id": "20",
            "title": "Smart Supply",
            "description": "Smart Supply",
            "url": "https://smartsupply-portal.captur.cloud/pages/overview",
            "tags": [
              "Würth"
            ],
            "grouping": "Lexit",
            "image1": "icons/lexit.jpg",
            "image2": "",
            "linkSet": "Application"
          },
          {
            "id": "26",
            "title": "Test Captur - Soti",
            "description": "Soti testmiljø for Captur",
            "url": "https://a0026119.mobicontrol.cloud/MobiControl/WebConsole/",
            "tags": [
              "Utvikling",
              "Lexit"
            ],
            "grouping": "Lexit",
            "image1": "icons/lexit.jpg",
            "image2": "icons/soti.png",
            "linkSet": "Application"
          },
          {
            "id": "21",
            "title": "Menzies | Confluence",
            "description": "Menzies Confluence mainpage",
            "url": "https://lexitgroup.atlassian.net/wiki/spaces/KUN/pages/62423065/Menzies+Aviation",
            "tags": [],
            "grouping": "Menzies",
            "image1": "icons/menzies.png",
            "image2": "icons/confluence.webp",
            "linkSet": "Application"
          },
          {
            "id": "22",
            "title": "Menzies | FactoryTalk",
            "description": "Menzies FactoryTalk",
            "url": "https://menziesaviation.lexitcloud.com/ftcw2/login",
            "tags": [],
            "grouping": "Menzies",
            "image1": "icons/menzies.png",
            "image2": "icons/ft.png",
            "linkSet": "Application"
          },
          {
            "id": "29",
            "title": "SAS Config Explanation Table",
            "description": "A table with details around the different configurations in SAS Factory Talk (POS)",
            "url": "https://lexitgroup.atlassian.net/wiki/spaces/KUN/database/1607368709",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/confluence.webp",
            "linkSet": "Application"
          },
          {
            "id": "16",
            "title": "SAS Eurobonus Portal",
            "description": "SAS Eurobonus Portal",
            "url": "https://sas.lexitcloud.com/eurobonus/login",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/eurobonus.png",
            "linkSet": "Application"
          },
          {
            "id": "14",
            "title": "SAS Hotel Web",
            "description": "SAS Hotel Web PROD",
            "url": "https://sashotelweb.lexitcloud.com/login",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/hotel.webp",
            "linkSet": "Application"
          },
          {
            "id": "17",
            "title": "SAS InFlight Portal",
            "description": "SAS InFlight Portal",
            "url": "https://sasservices.lexitcloud.com/login?returnUrl=%2Fpages%2Fdashboard",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/inflight.avif",
            "linkSet": "Application"
          },
          {
            "id": "18",
            "title": "SAS InFlight Soti",
            "description": "SAS InFlight Soti",
            "url": "https://sasmdm.lexitcloud.com/MobiControl/WebConsole",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/soti.png",
            "linkSet": "Application"
          },
          {
            "id": "28",
            "title": "SAS Telenor Prices",
            "description": "Telenor PriceZones for SAS - used to decide if a device should use EU/EES or NON EU/EES Firmware update policy",
            "url": "https://www.telenor.se/foretag/kundservice/utomlands/priser-i-utlandet-per-zon",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/telenor.png",
            "linkSet": "Application"
          },
          {
            "id": "3",
            "title": "SAS | Confluence",
            "description": "SAS Confluence mainpage",
            "url": "https://lexitgroup.atlassian.net/wiki/spaces/KUN/pages/11665409/Scandinavian+Airlines+System+SAS",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/confluence.webp",
            "linkSet": "Application"
          },
          {
            "id": "13",
            "title": "SAS | LGS | FactoryTalk",
            "description": "FactoryTalk for LGS clients",
            "url": "https://sas02.lexitcloud.com/ftcw2/login",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/ft.png",
            "linkSet": "Application"
          },
          {
            "id": "12",
            "title": "SAS | POS | FactoryTalk",
            "description": "FactoryTalk for POS clients",
            "url": "https://sas.lexitcloud.com/ftcw2/login",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/ft.png",
            "linkSet": "Application"
          },
          {
            "id": "6",
            "title": "SAS | POS | LAC",
            "description": "Asset Control for SAS POS",
            "url": "https://lex-sas.lexassetcontrol.com/login?returnUrl=%2Fpages%2Fdashboard",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/lac.png",
            "linkSet": "Application"
          },
          {
            "id": "4",
            "title": "SAS | Soti",
            "description": "SAS Soti",
            "url": "https://s098417.mobicontrolcloud.com/MobiControl/Webconsole",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/soti.png",
            "linkSet": "Application"
          },
          {
            "id": "27",
            "title": "Samsung Knox",
            "description": "Samsung Knox Portal for SAS Ground",
            "url": "https://central.samsungknox.com",
            "tags": [],
            "grouping": "SAS",
            "image1": "icons/sas.png",
            "image2": "icons/knox.png",
            "linkSet": "Application"
          },
          {
            "id": "35",
            "title": "TEST | BamaPortal",
            "description": "Test Portal for Bama Planograms",
            "url": "https://bamaportaltest.lexitcloud.com/login",
            "tags": [],
            "grouping": "TEST",
            "image1": "icons/lexit.jpg",
            "image2": "icons/bama.jpg",
            "linkSet": "Application"
          },
          {
            "id": "19",
            "title": "TEST | Lexit CentralTest FactoryTalk",
            "description": "FactoryTalk for Testing",
            "url": "https://centraltest.lexitgroup.com/login",
            "tags": [],
            "grouping": "TEST",
            "image1": "icons/lexit.jpg",
            "image2": "icons/ft.png",
            "linkSet": "Application"
          },
          {
            "id": "15",
            "title": "TEST | SAS Hotel Web TEST",
            "description": "SAS Hotel Web TEST",
            "url": "https://sashotelwebtest.lexitcloud.com/login",
            "tags": [],
            "grouping": "TEST",
            "image1": "icons/sas.png",
            "image2": "icons/hotel.webp",
            "linkSet": "Application"
          },
          {
            "id": "2",
            "title": "Teltonika RMS",
            "description": "Teltonika RMS Portal",
            "url": "https://rms.teltonika-networks.com/management/devices",
            "tags": [
              "Würth",
              "Tess",
              "SAS",
              "Monter",
              "Optimera AS"
            ],
            "grouping": "Tools",
            "image1": "icons/teltonika.png",
            "image2": "",
            "linkSet": "Application"
          },
          {
            "id": "11",
            "title": "Tools | Boarding Pass Generator",
            "description": "Create boarding pass for for example SAS testing",
            "url": "https://shooshx.github.io/BoardingBarcode/",
            "tags": [],
            "grouping": "Tools",
            "image1": "icons/boardingpass.png",
            "image2": "",
            "linkSet": "Application"
          },
          {
            "id": "32",
            "title": "Tools | Crontab Guru",
            "description": "Cron Schedule Expression Editor",
            "url": "https://crontab.guru",
            "tags": [],
            "grouping": "Tools",
            "image1": "icons/crontabguru.webp",
            "image2": "",
            "linkSet": "Application"
          },
          {
            "id": "30",
            "title": "Tools | HTML Viewer",
            "description": "HTML Online Viewer",
            "url": "https://html.onlineviewer.net",
            "tags": [],
            "grouping": "Tools",
            "image1": "icons/html-viewer.png",
            "image2": "",
            "linkSet": "Application"
          },
          {
            "id": "31",
            "title": "Tools | Labelary Online ZPL Viewer",
            "description": "Print view of ZPL code",
            "url": "https://labelary.com/viewer.html",
            "tags": [
              "Zebra"
            ],
            "grouping": "Tools",
            "image1": "icons/labelary.png",
            "image2": "",
            "linkSet": "Application"
          },
          {
            "id": "9",
            "title": "Tools | QR Code Generator",
            "description": "QR Code Generator",
            "url": "https://www.the-qrcode-generator.com",
            "tags": [
              "Bama"
            ],
            "grouping": "Tools",
            "image1": "icons/qr.png",
            "image2": "",
            "linkSet": "Application"
          },
          {
            "id": "10",
            "title": "Tools | QR Code Scanner",
            "description": "Scan QR code either with scanner or by uploading file",
            "url": "https://webqr.com",
            "tags": [
              "Bama",
              "SAS",
              "Würth"
            ],
            "grouping": "Tools",
            "image1": "icons/qr.png",
            "image2": "",
            "linkSet": "Application"
          },
          {
            "id": "23",
            "title": "Würth NO | FactoryTalk",
            "description": "Würth Norway Factory Talk",
            "url": "https://warehouse.wuerth.no/ftcw2/login",
            "tags": [],
            "grouping": "Würth",
            "image1": "icons/wurth.png",
            "image2": "icons/ft.png",
            "linkSet": "Application"
          },
          {
            "id": "24",
            "title": "Würth SE | FactoryTalk",
            "description": "Würth Sweden Factory Talk",
            "url": "https://warehouse.wurth.se/ftcw2/login",
            "tags": [],
            "grouping": "Würth",
            "image1": "icons/wurthse.jpg",
            "image2": "icons/ft.png",
            "linkSet": "Application"
          },
          {
            "id": "5",
            "title": "Würth | Confluence",
            "description": "Würth Confluence mainpage",
            "url": "https://lexitgroup.atlassian.net/wiki/spaces/KUN/pages/8814593/W+rth",
            "tags": [],
            "grouping": "Würth",
            "image1": "icons/wurth.png",
            "image2": "icons/confluence.webp",
            "linkSet": "Application"
          },
          {
            "id": "7",
            "title": "Würth | Soti",
            "description": "Würth Soti",
            "url": "https://s116344.mobicontrolcloud.com/MobiControl/Webconsole",
            "tags": [],
            "grouping": "Würth",
            "image1": "icons/wurth.png",
            "image2": "icons/soti.png",
            "linkSet": "Application"
          }
        ]
      }
    },
    {
      "name": "System",
      "file": "data/link-sets/System.json",
      "count": 1,
      "data": {
        "version": 1,
        "updatedAt": "2026-05-15",
        "name": "System",
        "links": [
          {
            "id": "40",
            "title": "LexService",
            "description": "LexService",
            "url": "https://lexservice.lexitgroup.com/Norge/",
            "tags": [
              "Lexit"
            ],
            "grouping": "Lexit",
            "image1": "icons/lexit.jpg",
            "image2": "icons/lexservice.png",
            "linkSet": "System"
          }
        ]
      }
    }
  ]
};
