window.QUICK_LINKS_CONFIG = {
  githubOwner: "RuneAa91",
  githubRepo: "lexitlinks",
  githubBranch: "main",
  requestIssueOwner: "RuneAa91",
  requestIssueRepo: "lexitlinks-version",
  issueLabels: ["lexitlinks-request"],
  packageName: "lexitlinks",
  publicVersionUrl: "https://raw.githubusercontent.com/RuneAa91/lexitlinks-version/main/version.json",
  publicPackageUrl: "https://raw.githubusercontent.com/RuneAa91/lexitlinks-version/main/lexitlinks-package.zip"
};
