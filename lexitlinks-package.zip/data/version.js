window.QUICK_LINKS_VERSION = {
  version: 5,
  updatedAt: "2026-05-17",
  message: "Fixed approved update notice after local upgrade",
  packageUrl: "https://raw.githubusercontent.com/RuneAa91/lexitlinks-version/main/lexitlinks-package.zip"
};
